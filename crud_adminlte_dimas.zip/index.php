<?php
include 'conf.php';
include 'template/header.php';
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-info"><i class="fas fa-box"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Barang</span>
                <?php
                $query = "SELECT COUNT(stok) as total_stok FROM barang";
                $result = mysqli_query($conn, $query);
                $data = mysqli_fetch_assoc($result);
                ?>
                <span class="info-box-number"><?=$data['total_stok'] ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-success"><i class="fas fa-shopping-cart"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Stok</span>
                <?php
                $query = "SELECT SUM(stok) as total_stok FROM barang";
                $result = mysqli_query($conn, $query);
                $data = mysqli_fetch_assoc($result);
                ?>
                <span class="info-box-number"><?=$data['total_stok'] ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <div class="row">
            <!-- /.col-md-6 -->
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title m-0">Selamat Datang di Aplikasi CRUD Barang</h5>
              </div>
              <div class="card-body">
                <h6 class="card-title">Aplikasi Ini Digunakan Wes Mbuh</h6>

                <p class="card-text">Fitur yang tersedia:</p>
                <ul>
                  <li>Menampilkan data barang</li>
                  <li>Menambah data barang baru</li>
                  <li>Mengedit data barang</li>
                  <li>Menghapus data barang</li>
                </ul>
                <a href="barang.php" class="btn btn-primary">Data Barang</a>
              </div>
            </div>

          </div>
          <!-- /.col-md-6 -->
          </div>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
<?php
include 'template/footer.php';
?>